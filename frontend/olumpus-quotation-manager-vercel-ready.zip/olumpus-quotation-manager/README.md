# Olumpus Quotation Manager

Quotation management system for **Olumpus Glasses Ltd.** — replaces manual Word-based quotations with a database-backed app that generates PDFs matching the original quotation template exactly.

## Status: Phase 9 — Print ✅ + Rate Calculator added

Print button now works in both New Quotation (edit mode) and Quotation History — opens the browser's native print dialog directly via a hidden iframe, no new tab needed.

**Also added (not a numbered phase, requested directly):** a Rate Calculator tool — full cost-buildup worksheet (Glass Basic → Landed Total → Total 1 → Total 2 → Rate Given), matching the business's real spreadsheet formulas exactly (verified numerically). Supports dynamic combination layers, an optional Precious Metal Surcharge toggle, and a one-click "push this rate to a linked product" action into Product Master.

## Project Structure

```
olumpus-quotation-manager/
├── frontend/                  React + Vite + Tailwind CSS
│   ├── src/
│   │   ├── pages/             Route-level pages (Dashboard, New Quotation, etc.) — Phase 4+
│   │   ├── components/        Reusable UI pieces (tables, forms, header) — Phase 4+
│   │   ├── layouts/           Shell layout (sidebar + topbar) — Phase 4
│   │   ├── lib/                Supabase client, API helpers — Phase 2+
│   │   ├── assets/             Images, logo
│   │   ├── App.jsx             Root component
│   │   ├── main.jsx            Entry point
│   │   └── index.css           Tailwind entry + brand theme tokens
│   ├── .env.example
│   ├── vite.config.js
│   └── package.json
│
├── backend/                   Node.js + Express API
│   ├── src/
│   │   ├── routes/             Express route definitions — Phase 3+
│   │   ├── controllers/        Route handler logic — Phase 3+
│   │   ├── config/              Supabase client, env config — Phase 2
│   │   ├── middleware/         Auth guard, error handling — Phase 3
│   │   ├── utils/               Reference number generator, PDF helpers — Phase 7+
│   │   └── server.js            Express app entry point
│   ├── .env.example
│   └── package.json
│
├── docs/                       SQL scripts, deployment notes (added in later phases)
├── .gitignore
└── README.md
```

## Why this stack (brief)

- **React + Vite**: fast dev server, simple build, deploys cleanly to Vercel's free tier.
- **Tailwind CSS v4**: utility-first styling, wired through the official `@tailwindcss/vite` plugin (no separate `postcss.config` needed in v4).
- **Express**: minimal, well-understood API layer; deploys to Render's free tier.
- **Supabase (Phase 2)**: free Postgres database + auth-ready, avoids running your own DB server.

## Prerequisites

- Node.js 18+ and npm installed on your machine.
- A terminal (this was built and tested on Node 20 / npm 10).

## Running locally

### 1. Frontend

```bash
cd frontend
npm install
npm run dev
```

Opens at **http://localhost:5173**. You should see a white card reading "Phase 1 setup complete."

### 2. Backend

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Runs at **http://localhost:5000**. Verify it's alive:

```bash
curl http://localhost:5000/api/health
```

Expected response:

```json
{"status":"ok","service":"Olumpus Quotation Manager API","timestamp":"..."}
```

## Common errors & fixes

| Error | Cause | Fix |
|---|---|---|
| `EADDRINUSE: address already in use :::5000` | Another process is already using port 5000 | Kill it: `lsof -ti:5000 \| xargs kill -9` (Mac/Linux) or change `PORT` in `backend/.env` |
| `Cannot find module 'express'` | Dependencies not installed | Run `npm install` inside `backend/` |
| Tailwind classes not applying | `@tailwindcss/vite` plugin missing from `vite.config.js`, or dev server not restarted after config change | Confirm `vite.config.js` includes `tailwindcss()` in `plugins`, then restart `npm run dev` |
| Blank white page in browser | Usually a JS error — check the browser console | Open DevTools console for the stack trace |
| `npm create vite` fails / hangs | Slow or blocked network | Retry, or check your network/proxy settings |

## What's next (Phase 10)

Deployment: frontend to Vercel, backend to Render (with the Puppeteer/Chromium considerations that platform needs), Supabase already live. Environment variables, build commands, and a final end-to-end smoke test on the real deployed URLs.

Waiting for your go-ahead before starting Phase 10.
